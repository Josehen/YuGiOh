package com.jose.recycleviewimage.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.view.menu.MenuView
import androidx.recyclerview.widget.RecyclerView
import com.jose.recycleviewimage.model.produts
import com.jose.yugioh.R

class AdapterImage(private val context: Context, private val produtos: MutableList<produts>): RecyclerView.Adapter<AdapterImage.imageviewholder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): imageviewholder {
        val imagelist = LayoutInflater.from(context).inflate(R.layout.image_white,parent,false)
        val holder = imageviewholder(imagelist)
        return holder
    }

    override fun onBindViewHolder(holder: imageviewholder, position: Int) {
        holder.image.setImageResource(produtos[position].image)
    }

    override fun getItemCount(): Int =produtos.size


    inner class imageviewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
       val image = itemView.findViewById<ImageView>(R.id.imagecard)
    }
}