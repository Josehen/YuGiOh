package com.jose.yugioh

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jose.recycleviewimage.Adapter.AdapterImage
import com.jose.recycleviewimage.model.produts

class MainActivitymorear : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_activitymorear)
        supportActionBar!!.hide()
        val Recyclerview = findViewById<RecyclerView>(R.id.Recyclerview)
        Recyclerview.layoutManager = LinearLayoutManager(this)
        Recyclerview.setHasFixedSize(true)

        val listaprodutos: MutableList<produts> = mutableListOf()
        val adapterproduto = AdapterImage(this, listaprodutos)
        Recyclerview.adapter = adapterproduto

        val card1 = produts(
            R.drawable.blueeyesewitedragon
        )
        listaprodutos.add(card1)
        val card2 = produts(
            R.drawable.drolllockbird
        )
        listaprodutos.add(card2)
        val card4 = produts(
            R.drawable.blueeyesewitedragon
        )
        listaprodutos.add(card4)
        val card5 = produts(
            R.drawable.blueeyesewitedragon
        )
        listaprodutos.add(card5)





    }
}