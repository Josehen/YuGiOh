package com.jose.recycleviewimage.model

data class produts(
    val image: Int

)